package com.ds.securecampus.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "materias", uniqueConstraints = {
        @UniqueConstraint(name = "uk_materia_carrera_clave", columnNames = { "id_carrera", "clave_materia" }),
        @UniqueConstraint(name = "uk_materia_id_carrera", columnNames = { "materia_id", "id_carrera" })
})
public class Materia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "materia_id")
    private Long materiaId;

    @Column(name = "clave_materia", nullable = false, length = 20)
    private String clave;

    @Column(name = "nombre_materia", nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, precision = 2, scale = 0)
    private BigDecimal creditos;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_carrera", nullable = false)
    private Carrera carrera;
}
