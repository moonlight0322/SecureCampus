package com.ds.securecampus.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ds.securecampus.model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, String> {
    @Override
    @EntityGraph(attributePaths = "rol")
    java.util.List<Usuario> findAll();

    @EntityGraph(attributePaths = "rol")
    Optional<Usuario> findByNumeroControl(String numeroControl);

    boolean existsByCorreoInstitucional(String correoInstitucional);
}
