package com.ds.securecampus.model;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import org.hibernate.annotations.ColumnDefault;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "cargas_academicas", uniqueConstraints = @UniqueConstraint(name = "uk_estudiante_grupo", columnNames = {
        "numero_control_estudiante", "grupo_id" }))
public class CargaAlumno {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "carga_id")
    private Long cargaId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "numero_control_estudiante", nullable = false)
    private Estudiante estudiante;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "grupo_id", nullable = false)
    private Grupo grupo;

    @Column(name = "calificacion_parcial1", precision = 5, scale = 2)
    private BigDecimal calificacionParcial1;

    @Column(name = "calificacion_parcial2", precision = 5, scale = 2)
    private BigDecimal calificacionParcial2;

    @Column(name = "calificacion_final", precision = 5, scale = 2)
    private BigDecimal calificacionFinal;

    @Column(nullable = false, length = 20)
    @ColumnDefault("'CURSANDO'")
    private String estatus = "CURSANDO";

    @Column(nullable = false, length = 20)
    @ColumnDefault("'PRIMERA'")
    private String oportunidad = "PRIMERA";
}
