package com.ds.securecampus.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ds.securecampus.model.CargaAlumno;
import com.ds.securecampus.model.Grupo;
import com.ds.securecampus.model.Periodo;
import com.ds.securecampus.model.Profesor;
import com.ds.securecampus.repository.CargaAlumnoRepository;
import com.ds.securecampus.repository.GrupoRepository;
import com.ds.securecampus.repository.ProfesorRepository;
import com.ds.securecampus.repository.SolicitudTramiteRepository;

@Service
public class ProfesorService {
    private final GrupoRepository grupoRepository;
    private final CargaAlumnoRepository cargaAlumnoRepository;
    private final ProfesorRepository profesorRepository;
    private final AuditoriaService auditoriaService;
    private final NotificacionService notificacionService;
    private final SolicitudTramiteRepository solicitudRepository;
    private final com.ds.securecampus.repository.HorarioClaseRepository horarioClaseRepository;

    public ProfesorService(GrupoRepository grupoRepository,
            CargaAlumnoRepository cargaAlumnoRepository,
            ProfesorRepository profesorRepository,
            AuditoriaService auditoriaService,
            NotificacionService notificacionService,
            SolicitudTramiteRepository solicitudRepository,
            com.ds.securecampus.repository.HorarioClaseRepository horarioClaseRepository) {
        this.grupoRepository = grupoRepository;
        this.cargaAlumnoRepository = cargaAlumnoRepository;
        this.profesorRepository = profesorRepository;
        this.auditoriaService = auditoriaService;
        this.notificacionService = notificacionService;
        this.solicitudRepository = solicitudRepository;
        this.horarioClaseRepository = horarioClaseRepository;
    }

    @Transactional(readOnly = true)
    public List<Grupo> obtenerGruposProfesor(String numeroControl) {
        return grupoRepository.findByProfesorNumeroControl(numeroControl);
    }

    @Transactional(readOnly = true)
    public Profesor obtenerProfesor(String numeroControl) {
        return profesorRepository.findByNumeroControl(numeroControl)
                .orElseThrow(() -> new IllegalArgumentException("Perfil de profesor no encontrado."));
    }

    @Transactional(readOnly = true)
    public Grupo obtenerGrupo(Long grupoId) {
        return grupoRepository.findById(grupoId).orElseThrow(() -> new IllegalArgumentException("Grupo no encontrado"));
    }

    @Transactional(readOnly = true)
    public Grupo obtenerGrupoProfesor(Long grupoId, String profesorControl) {
        Grupo grupo = obtenerGrupo(grupoId);
        validarProfesorAsignado(grupo, profesorControl);
        return grupo;
    }

    @Transactional(readOnly = true)
    public List<CargaAlumno> obtenerAlumnosGrupo(Long grupoId) {
        return cargaAlumnoRepository.findByGrupoGrupoId(grupoId);
    }

    @Transactional(readOnly = true)
    public boolean puedeCapturar(Grupo grupo) {
        if (grupo == null || grupo.getPeriodo() == null || grupo.getGrupoId() == null)
            return false;
        Periodo per = grupo.getPeriodo();

        // Obtenemos la fecha actual y la fecha límite o fin del periodo/semestre
        java.time.LocalDate hoy = java.time.LocalDate.now();
        java.time.LocalDate fechaFin = per.getFechaFin();

        // La captura estará abierta durante todo el semestre (mientras no rebase la
        // fecha de fin), o si el administrador aprobó un desbloqueo extraordinario.
        boolean semestreActivo = (fechaFin == null || !hoy.isAfter(fechaFin));

        return semestreActivo
                || solicitudRepository.existsByGrupoIdAndTipoTramiteIgnoreCaseAndEstatusIgnoreCase(
                        grupo.getGrupoId(), "DESBLOQUEO_CAPTURA", "APROBADA");
    }

    @Transactional
    public void guardarCalificacion(Long grupoId, Long cargaId, BigDecimal p1, BigDecimal p2,
            String profesorControl) {
        CargaAlumno carga = cargaAlumnoRepository.findById(cargaId)
                .orElseThrow(() -> new IllegalArgumentException("Carga no encontrada"));

        Grupo grupo = carga.getGrupo();
        if (grupo.getGrupoId() == null || !grupo.getGrupoId().equals(grupoId)) {
            throw new IllegalArgumentException("La carga del estudiante no pertenece al grupo indicado.");
        }
        validarProfesorAsignado(grupo, profesorControl);
        if (!puedeCapturar(grupo)) {
            throw new IllegalStateException(
                    "El periodo de captura se encuentra cerrado para este grupo. Solicite desbloqueo al administrador.");
        }

        // Validación de rango 0 a 100
        if (p1 != null && (p1.compareTo(BigDecimal.ZERO) < 0 || p1.compareTo(new BigDecimal("100")) > 0)) {
            throw new IllegalArgumentException("La calificación parcial 1 debe estar entre 0 y 100.");
        }
        if (p2 != null && (p2.compareTo(BigDecimal.ZERO) < 0 || p2.compareTo(new BigDecimal("100")) > 0)) {
            throw new IllegalArgumentException("La calificación parcial 2 debe estar entre 0 y 100.");
        }

        carga.setCalificacionParcial1(p1);
        carga.setCalificacionParcial2(p2);

        // Promedio automático
        if (p1 != null && p2 != null) {
            BigDecimal finalScore = p1.add(p2).divide(new BigDecimal("2"), 2, RoundingMode.HALF_UP);
            carga.setCalificacionFinal(finalScore);
            if (finalScore.compareTo(new BigDecimal("70")) >= 0) {
                carga.setEstatus("APROBADA");
            } else {
                carga.setEstatus("REPROBADA");
            }
        } else {
            carga.setCalificacionFinal(null);
            carga.setEstatus("CURSANDO");
        }

        cargaAlumnoRepository.save(carga);

        String alumnoControl = carga.getEstudiante().getNumeroControl();
        auditoriaService.registrar(profesorControl, "PROFESOR", "CAPTURA_CALIFICACION",
                "Calificación guardada para estudiante " + alumnoControl + " en grupo " + grupo.getCodigoGrupo() +
                        ": P1=" + p1 + ", P2=" + p2 + ", Final=" + carga.getCalificacionFinal(),
                "127.0.0.1");

        // Notificar al estudiante sobre la publicación/actualización de notas
        notificacionService.enviar(alumnoControl, "Calificaciones Actualizadas",
                "Tu profesor ha publicado nuevas calificaciones en la materia: " + grupo.getMateria().getNombre());
    }

    private void validarProfesorAsignado(Grupo grupo, String profesorControl) {
        if (grupo.getProfesor() == null
                || !profesorControl.equals(grupo.getProfesor().getNumeroControl())) {
            throw new IllegalArgumentException("El grupo no está asignado a este profesor.");
        }
    }

    @Transactional(readOnly = true)
    public List<com.ds.securecampus.model.HorarioSemanalFila> obtenerHorarioSemanalProfesor(String numeroControl) {
        List<Grupo> grupos = grupoRepository.findByProfesorNumeroControl(numeroControl);
        java.util.Map<java.time.LocalTime, com.ds.securecampus.model.HorarioSemanalFila> filas = new java.util.TreeMap<>();
        for (Grupo g : grupos) {
            List<com.ds.securecampus.model.HorarioClase> horarios = horarioClaseRepository
                    .findByGrupoGrupoId(g.getGrupoId());
            for (com.ds.securecampus.model.HorarioClase h : horarios) {
                java.time.LocalTime inicio = java.time.LocalTime.parse(h.getHoraInicio());
                java.time.LocalTime fin = java.time.LocalTime.parse(h.getHoraFin());
                for (java.time.LocalTime hora = inicio; hora.isBefore(fin); hora = hora.plusHours(1)) {
                    java.time.LocalTime sig = hora.plusHours(1);
                    String tramo = hora + " - " + sig;
                    com.ds.securecampus.model.HorarioSemanalFila fila = filas.computeIfAbsent(hora,
                            ignored -> new com.ds.securecampus.model.HorarioSemanalFila(tramo));
                    String aulaNombre = h.getAula() != null ? h.getAula().getNombreAula() : "Por asignar";
                    String detalle = g.getCodigoGrupo() + " · " + g.getMateria().getNombre() + " (" + aulaNombre + ")";
                    fila.agregarClase(h.getDiaSemana(), detalle);
                }
            }
        }
        return List.copyOf(filas.values());
    }

    @Transactional(readOnly = true)
    public List<com.ds.securecampus.model.EstadisticaGrupo> obtenerEstadisticasGrupos(String numeroControl) {
        List<Grupo> grupos = grupoRepository.findByProfesorNumeroControl(numeroControl);
        List<com.ds.securecampus.model.EstadisticaGrupo> stats = new java.util.ArrayList<>();
        for (Grupo g : grupos) {
            List<CargaAlumno> cargas = cargaAlumnoRepository.findByGrupoGrupoId(g.getGrupoId());
            int total = cargas.size();
            int aprobados = 0;
            int reprobados = 0;
            int cursando = 0;
            double suma = 0;
            int conNota = 0;
            for (CargaAlumno c : cargas) {
                if ("APROBADA".equalsIgnoreCase(c.getEstatus()))
                    aprobados++;
                else if ("REPROBADA".equalsIgnoreCase(c.getEstatus()))
                    reprobados++;
                else
                    cursando++;

                if (c.getCalificacionFinal() != null) {
                    suma += c.getCalificacionFinal().doubleValue();
                    conNota++;
                }
            }
            double prom = conNota > 0 ? Math.round((suma / conNota) * 100.0) / 100.0 : 0.0;
            String profName = g.getProfesor() != null && g.getProfesor().getUsuario() != null
                    ? g.getProfesor().getUsuario().getNombre() + " " + g.getProfesor().getUsuario().getApellidoPaterno()
                    : "Docente";
            stats.add(new com.ds.securecampus.model.EstadisticaGrupo(
                    g.getGrupoId(),
                    g.getCodigoGrupo(),
                    g.getMateria().getNombre(),
                    profName,
                    total,
                    35,
                    aprobados,
                    reprobados,
                    cursando,
                    prom));
        }
        return stats;
    }
}
